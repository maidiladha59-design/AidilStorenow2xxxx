export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 lg:px-8 py-14">
      <h1 className="font-display text-3xl font-bold text-ink-950 mb-6">Tentang Kami</h1>
      <div className="space-y-4 text-sm text-ink-700 leading-relaxed">
        <p>
          AIDIL STORE adalah platform layanan digital yang membantu mahasiswa dan masyarakat umum
          menyelesaikan kebutuhan tugas dan pekerjaan digital — mulai dari jasa ketik, resume/CV,
          makalah, presentasi, desain grafis, hingga produk digital siap pakai.
        </p>
        <p>
          Kami percaya setiap orang berhak mendapatkan bantuan yang cepat, rapi, dan transparan
          soal harga — tanpa proses yang berbelit. Tim kami siap membantu dari konsultasi kebutuhan
          sampai hasil akhir diterima.
        </p>
      </div>
    </div>
  );
}
